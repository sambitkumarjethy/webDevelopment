package com.codingshuttle.jpaTutorial.jpaTuts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaTutorialApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaTutorialApplication.class, args);
	}

}
